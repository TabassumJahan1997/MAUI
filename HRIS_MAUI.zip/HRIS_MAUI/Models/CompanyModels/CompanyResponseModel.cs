﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Models.CompanyModels
{
    public class CompanyResponseModel
    {
        public int CompanyId { get; set; }

        public string CompanyName { get; set; }

        public string? CompanyAlias { get; set; }

        public string Address { get; set; }

        public string Phone { get; set; }

        public string? Fax { get; set; }

        public string Email { get; set; }

        public string? Website { get; set; }

        public string? CompanyRegisterNo { get; set; }

        public int IsActive { get; set; }

        public int? CreateBy { get; set; }

        public DateTime CreateDate { get; set; } = DateTime.Now;

        public int? UpdateBy { get; set; }

        public DateTime UpdateDate { get; set; } = DateTime.Now;

    }
}
