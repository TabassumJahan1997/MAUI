﻿using Models;
using Models.CompanyModels;

namespace IServices
{
    public interface ICompanyService
    {
        Task<List<CompanyResponseModel>> GetAllCompanyList();
        Task<MainResponseModel> AddCompany(AddUpdateCompanyRequest companyRequest);
        Task<MainResponseModel> UpdateCompany(AddUpdateCompanyRequest companyRequest);
        Task<MainResponseModel> DeleteCompany(AddUpdateCompanyRequest companyRequest);
        Task<CompanyResponseModel> GetCompanyDetailsByCompanyID(int companyId);
    }
}